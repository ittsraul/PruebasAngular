export interface One {
    image : string[],     
    class : string ,   
    caption : string 
}
